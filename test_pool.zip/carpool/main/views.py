from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Ride
from django.contrib.auth.models import User
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib import messages
from django.shortcuts import render, redirect
from django.core.mail import send_mail

# Home view
def home_view(request):
    return render(request, 'home.html')

# Find ride view
def find_ride_view(request):
    rides = Ride.objects.all()  # Get all rides
    return render(request, 'find_ride.html', {'rides': rides})

# Login view
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login
from django.shortcuts import render, redirect

# Login view
def login_view(request):
    error_message = None  # Initialize error message
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)

            # Redirect to the next page after login
            next_url = request.GET.get('next', 'home')  # Use next parameter if it exists
            return redirect(next_url)  # Default to home page if no 'next' parameter
        else:
            error_message = "Invalid username or password. Please try again."  # Set error message
    else:
        form = AuthenticationForm()

    return render(request, 'login.html', {'form': form, 'error_message': error_message})

# Register view
from django.contrib import messages
from django.shortcuts import redirect, render
from django.contrib.auth.models import User

def register_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        
        # Check password match
        if password1 != password2:
            messages.error(request, "Passwords do not match.")
        
        # Check if username already exists
        elif User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('register')
        
        # Check if email already exists
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists.")
            return redirect('register')

        # If no issues, create the user
        else:
            user = User.objects.create_user(username=username, email=email, password=password1)
            user.save()
            messages.success(request, "Account created successfully.")
            return redirect('login')  # Redirect to the login page
        
    return render(request, 'register.html')




# Publish ride view (only accessible when logged in)
@login_required  # Ensure the user is logged in before accessing this view
def publish_ride_view(request):
    if request.method == 'POST':
        # Save the ride details with the logged-in user as the rider
        ride = Ride(
            user=request.user,
            origin=request.POST['origin'],
            destination=request.POST['destination'],
            vehical_type=request.POST['vehical_type'],
            vehical_details=request.POST['vehical_details'],
            vehical_number=request.POST['vehical_number'],
            driving_license=request.POST['driving_license'],
            departure_time=request.POST['departure_time'],
            seats_available=request.POST['seats_available'],
            price=request.POST['price'],
            details=request.POST.get('details', ''),  # Optional additional details
            username=request.user.username,  # Save the username
        )
        ride.save()
        return redirect('home')  # Redirect to the home page after publishing the ride

    return render(request, 'publish_ride.html')

## for find ride
from django.shortcuts import render
from .models import Ride
from django.contrib.auth.decorators import login_required

def find_ride_view(request):
    # Get search parameters from GET request
    origin = request.GET.get('origin', '')
    destination = request.GET.get('destination', '')
    date = request.GET.get('date', '')
    vehicle_type = request.GET.get('vehicle_type', '')


    # Filter rides based on search criteria
    rides = Ride.objects.filter(status='Scheduled')  # Only show scheduled rides

    if origin:
        rides = rides.filter(origin__icontains=origin)
    if destination:
        rides = rides.filter(destination__icontains=destination)
    if date:
        rides = rides.filter(departure_time__date=date)
    if vehicle_type:
        rides = rides.filter(vehicle_type__icontains=vehicle_type)

    return render(request, 'find_ride.html', {'rides': rides})


# after logged in dropdown options

from django.shortcuts import render
from django.contrib.auth.decorators import login_required

#display publish rides to rider
@login_required
def your_rides(request):
    scheduled_rides = Ride.objects.filter(user=request.user, status__in=['Scheduled', 'Cancelled'])
    booked_rides = Ride.objects.filter(username=request.user.username, status__in=['Booked', 'Cancelled'])  # Change here
    return render(request, 'your_rides.html', {'scheduled_rides': scheduled_rides, 'booked_rides': booked_rides})

@login_required
def profile(request):
    user = request.user
    return render(request, 'profile.html', {'user': user})


# cancel the scheduled ride# views.py
from django.shortcuts import render, get_object_or_404, redirect
from .models import Ride

def cancel_ride(request, ride_id):
    ride = get_object_or_404(Ride, id=ride_id)
    if request.method == 'POST':
        ride.status = 'Cancelled'
        ride.save()
        return redirect('your_rides')  # Replace 'your_rides' with your actual view name

# book ride
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Ride
from django.shortcuts import get_object_or_404, redirect
import win32com.client as win32
import pythoncom

def send_email_reminder(rider_email, driver_email, ride):
    pythoncom.CoInitialize()  # Initialize COM
    outlook = win32.Dispatch('outlook.application')
    subject = 'Ride Confirmation'

    
 # Email body for the rider
    rider_body = f"""
    Dear {ride.username},

    Your ride has been confirmed with the following details:

    Origin: {ride.origin}
    Destination: {ride.destination}
    Vehicle Type: {ride.vehical_type}
    Vehicle Details: {ride.vehical_details}
    Departure Time: {ride.departure_time}
    Seats Available: {ride.seats_available}
    Price: {ride.price}

    Thank you for using our service!

    Best Regards,
    Ride Share
    """

    # Email body for the driver
    driver_body = f"""
    Dear {ride.user.username},

    You have a new ride booking with the following details:

    Origin: {ride.origin}
    Destination: {ride.destination}
    Vehicle Type: {ride.vehical_type}
    Vehicle Details: {ride.vehical_details}
    Departure Time: {ride.departure_time}
    Seats Available: {ride.seats_available}
    Price: {ride.price}

    Thank you for being a part of our service!

    Best Regards,
    Ride Share
    """

    # Send email to the rider
    mail_rider = outlook.CreateItem(0)
    mail_rider.To = rider_email
    mail_rider.Subject = subject
    mail_rider.Body = rider_body
    mail_rider.Send()
    print(f'Reminder sent to rider email: {rider_email}')

    # Send email to the driver
    mail_driver = outlook.CreateItem(0)
    mail_driver.To = driver_email
    mail_driver.Subject = subject
    mail_driver.Body = driver_body  # Customize for driver
    mail_driver.Send()
    print(f'Reminder sent to driver email: {driver_email}')


@login_required
def book_ride_view(request, ride_id):
    ride = get_object_or_404(Ride, id=ride_id)

    if request.method == 'POST':
        
        # Check if there are seats available
        if ride.seats_available > 0:
            ride.seats_available -= 1  # Reduce the seat count by 1
            ride.status = 'Booked'  # Set status to Booked
            ride.username = request.user.username  # Set the booked_by field
            ride.save()
             # Send email to both rider and driver
            send_email_reminder(request.user.email, ride.user.email, ride)
            # Redirect to a 'success' page or any other page
            return redirect('your_rides')  # Update with the correct URL name if different
        else:
            # Optional: add a message indicating no seats are available
            messages.error(request, "No seats available for this ride.")
            return redirect('find_ride')  # Redirect back to the find ride page or an appropriate view
    else:
        # Redirect to the find ride page if accessed through GET
        return redirect('find_ride')
    
# Detailed publish ride details

def ride_detail(request, ride_id):
    ride = get_object_or_404(Ride, id=ride_id)
    return render(request, 'ride_detail.html', {'ride': ride})

#Edit profile
@login_required
def edit_profile(request):
    user = request.user

    if request.method == 'POST':
        # Update email
        new_email = request.POST.get('email', '').strip()  # Get the new email from the request
        if new_email and new_email != user.email:  # Check if new email is provided and is different from the current email
            user.email = new_email  # Update the user's email
            user.save()  # Save the changes to the user
            messages.success(request, "Email updated successfully.")  # Show success message
            
        # Handle password change
        password_form = PasswordChangeForm(user, request.POST)
        if password_form.is_valid():
            user = password_form.save()  # Save the user object with the new password
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, "Password updated successfully.")
        else:
            for error in password_form.errors.values():
                messages.error(request, error)  # Show all errors from the form

        return redirect('edit_profile')  # Redirect to the profile page

    password_form = PasswordChangeForm(user)
    return render(request, 'edit_profile.html', {'user': user, 'password_form': password_form})