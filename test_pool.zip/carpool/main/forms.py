from django import forms
from .models import Ride

class RideForm(forms.ModelForm):
    class Meta:
        model = Ride
        fields = ['origin', 'destination', 'vehical_type', 'vehical_details', 'vehical_number', 'driving_license', 'departure_time', 'seats_available', 'price', 'details']
