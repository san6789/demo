from django.db import models
from django.contrib.auth.models import User

from django.db import models
from django.contrib.auth.models import User

class Ride(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Associate ride with user
    origin = models.CharField(max_length=255)
    destination = models.CharField(max_length=255)
    vehical_type = models.CharField(max_length=255, default=None, null=True, blank=True)
    vehical_details = models.CharField(max_length=255, default=None, null=True, blank=True)
    vehical_number = models.CharField(max_length=255, default=None, null=True, blank=True)
    driving_license = models.CharField(max_length=20, default=None, null=True, blank=True)  # Default to None
    departure_time = models.DateTimeField()
    seats_available = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    details = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, default='Scheduled')
    username = models.CharField(max_length=150)  # Add this line

    def __str__(self):
        return f"Ride from {self.origin} to {self.destination} by {self.user.username}"

