from django.urls import path
from . import views


urlpatterns = [
    path('', views.home_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('publish-ride/', views.publish_ride_view, name='publish_ride'),
    path('find-ride/', views.find_ride_view, name='find_ride'),
    path('cancel_ride/<int:ride_id>/', views.cancel_ride, name='cancel_ride'),
    path('book_ride/<int:ride_id>/', views.book_ride_view, name='book_ride'),
    path('ride/<int:ride_id>/', views.ride_detail, name='ride_detail'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    path('environment/', views.environment, name='environment'),
]
