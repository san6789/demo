import requests

def get_distance(origin, destination, api_key):
    url = f"https://maps.googleapis.com/maps/api/distancematrix/json?origins={origin}&destinations={destination}&key={api_key}"
    response = requests.get(url)
    data = response.json()

    if data["status"] == "OK":
        distance_text = data["rows"][0]["elements"][0]["distance"]["text"]
        distance_value = data["rows"][0]["elements"][0]["distance"]["value"] / 1000  # Convert to kilometers
        return distance_text, distance_value
    else:
        return None, None

# Example Usage
origin = "koti , Hyderabad"
destination = "gachibowli , Hyderabad"
api_key = "AIzaSyBp2ooTNm0R7gNpDb-ZdutR9o5bNNZFxa8"

distance_text, distance_km = get_distance(origin, destination, api_key)
print(f"Distance: {distance_text} ({distance_km} km)")
def calculate_fuel_efficiency(distance_km, fuel_consumption_l, passengers):
    """
    Calculate fuel efficiency for a rideshare.
    
    Parameters:
        distance_km (float): Total distance of the ride in kilometers.
        fuel_consumption_l (float): Total fuel consumed during the ride in liters.
        passengers (int): Number of passengers sharing the ride.

    Returns:
        float: Fuel efficiency in km/l per passenger.
    """
    if passengers <= 0:
        raise ValueError("Passengers must be greater than 0.")
    
    if fuel_consumption_l <= 0:
        raise ValueError("Fuel consumption must be greater than 0.")
    
    # Calculate overall fuel efficiency
    total_efficiency = distance_km / fuel_consumption_l
    
    
    # individual fule efficiency
    individual_efficiency = total_efficiency
    # Per-passenger fuel efficiency
    per_person_efficiency = total_efficiency * passengers

    return per_person_efficiency, individual_efficiency


# Example usage
if __name__ == "__main__":
    try:
        # Inputs
        total_distance = float(f"{distance_km}")
        total_fuel = float(15)
        number_of_passengers = int(4)

        # Calculate per-person efficiency
        efficiency , individual_efficiency = calculate_fuel_efficiency(total_distance, total_fuel, number_of_passengers)
        print(f"Rideshare Fuel Efficiency per Passenger: {efficiency:.2f} km/l")
        print(f"Rideshare Fuel Efficiency individual Passenger: {individual_efficiency:.2f} km/l")
    except ValueError as e:
        print(f"Input Error: {e}")
