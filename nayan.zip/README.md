# Share ride

## execution commands

```bash
cd carpool
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

## Docker commands

```bash
docker build -t django-app .
docker run -d -p 8000:8000 --name django-container django-app
http://localhost:8000/
docker stop django-container
docker rm django-container
```
