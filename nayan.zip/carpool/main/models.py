from django.db import models

class Ride(models.Model):
    STATUS_CHOICES = [
        ('Scheduled', 'Scheduled'),
        ('Cancelled', 'Cancelled'),
        ('Booked', 'Booked')
    ]
    ride_id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=100)
    origin = models.CharField(max_length=100)
    destination = models.CharField(max_length=100)
    departure_time = models.DateTimeField()
    vehical_number = models.CharField(max_length=20)
    vehical_details = models.TextField()
    vehical_type = models.CharField(max_length=50)
    driving_license = models.CharField(max_length=50)
    seats_available = models.IntegerField()
    price = models.DecimalField(max_digits=6, decimal_places=2)
    details = models.TextField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Scheduled')

class Booking(models.Model):
    booking_id = models.AutoField(primary_key=True)
    ride = models.ForeignKey(Ride, on_delete=models.CASCADE)
    username = models.CharField(max_length=100)
    number_of_seats_booked = models.IntegerField()
    name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)
    booking_status = models.CharField(max_length=10, choices=[('Booked', 'Booked'), ('Cancelled', 'Cancelled')], default='Booked')